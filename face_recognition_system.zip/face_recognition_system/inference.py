
# inference.py
import os
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from model import FaceEmbeddingNet
from scipy.spatial.distance import cosine

# Config
EMBEDDING_DIR = "./embeddings"
THRESHOLD = 0.001  # Tune this based on validation/test performance
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Transform
transform = transforms.Compose([
    transforms.Resize((160, 160)),
    transforms.ToTensor(),
    transforms.Normalize([0.5]*3, [0.5]*3)
])

# Load trained model
model = FaceEmbeddingNet()
model.load_state_dict(torch.load("model_epoch_20.pth", map_location=DEVICE))
model.eval().to(DEVICE)

# Load gallery embeddings
gallery = {}
for file in os.listdir(EMBEDDING_DIR):
    if file.endswith(".npy"):
        name = file[:-4]
        emb = np.load(os.path.join(EMBEDDING_DIR, file))
        gallery[name] = emb

def recognize(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0).to(DEVICE)

    with torch.no_grad():
        embedding = model(image).cpu().numpy()[0]

    # Compare with gallery embeddings
    best_match = None
    best_score = float("inf")
    for name, known_emb in gallery.items():
        score = cosine(embedding, known_emb)
        if score < best_score:
            best_score = score
            best_match = name

    # Thresholding logic
    if best_score < THRESHOLD:
        print(f"✅ Recognized as: {best_match} (score: {best_score:.4f})")
    else:
        print(f"❌ Unknown face (score: {best_score:.4f})")

# Example usage
if __name__ == "__main__":
    print("This image (/Users/mac/Downloads/1886842.png) should not be identified\n")
    print("Beacuse it was not  during the training\n")
    #recognize("/Users/mac/Downloads/face_recog_emb/data/lfw/Aaron_Eckhart/Aaron_Eckhart_0001.jpg")
    recognize("/Users/mac/Downloads/1886842.png")



