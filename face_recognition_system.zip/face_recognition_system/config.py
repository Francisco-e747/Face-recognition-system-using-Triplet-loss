
# config.py
BATCH_SIZE = 32
EMBEDDING_DIM = 128
MARGIN = 0.5
EPOCHS = 20
LR = 1e-3
DEVICE = "cuda"  # or fallback to "cpu"

