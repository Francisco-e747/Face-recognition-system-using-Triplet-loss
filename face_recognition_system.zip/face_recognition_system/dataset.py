
#dataset.py
import os
import random
from PIL import Image
from torch.utils.data import Dataset


class TripletLFWDataset(Dataset):
    def __init__(self, root_dir, transform=None, min_images_per_class=10):
        self.root_dir = root_dir
        self.transform = transform
        self.label_to_images = {}

        # Collect valid identities with >= min_images_per_class
        for person in os.listdir(root_dir):
            person_dir = os.path.join(root_dir, person)
            if not os.path.isdir(person_dir):
                continue
            images = [
                os.path.join(person_dir, img)
                for img in os.listdir(person_dir)
                if img.lower().endswith(('.jpg', '.jpeg', '.png'))
            ]
            if len(images) >= min_images_per_class:
                self.label_to_images[person] = images

        self.persons = list(self.label_to_images.keys())

    def __len__(self):
        return 10000  # Can be adjusted or computed dynamically

    def __getitem__(self, idx):
        # Select anchor and positive
        anchor_person = random.choice(self.persons)
        positive_imgs = random.sample(self.label_to_images[anchor_person], 2)
        anchor_img_path, positive_img_path = positive_imgs

        # Select negative from another person
        negative_person = random.choice([p for p in self.persons if p != anchor_person])
        negative_img_path = random.choice(self.label_to_images[negative_person])

        # Load and transform images
        anchor_img = Image.open(anchor_img_path).convert('RGB')
        positive_img = Image.open(positive_img_path).convert('RGB')
        negative_img = Image.open(negative_img_path).convert('RGB')

        if self.transform:
            anchor_img = self.transform(anchor_img)
            positive_img = self.transform(positive_img)
            negative_img = self.transform(negative_img)

        return anchor_img, positive_img, negative_img


