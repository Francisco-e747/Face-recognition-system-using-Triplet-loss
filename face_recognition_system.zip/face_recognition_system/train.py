

#train.py
import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from tqdm import tqdm
from sklearn.metrics import roc_auc_score, accuracy_score
from PIL import Image

from dataset import TripletLFWDataset  # Your triplet dataset
from model import FaceEmbeddingNet
from loss import TripletLoss

# --- Validation Dataset for Pairs ---
class ValidationPairsDataset(Dataset):
    def __init__(self, root_dir, valid_names, transform=None, num_pairs=1000):
        """
        Create pairs of images with labels: 1 if same person, 0 if different.
        """
        self.root_dir = root_dir
        self.valid_names = valid_names
        self.transform = transform
        self.num_pairs = num_pairs

        # Build a dict of person -> list of images
        self.person_to_images = {}
        for person in valid_names:
            person_dir = os.path.join(root_dir, person)
            images = [
                os.path.join(person_dir, img)
                for img in os.listdir(person_dir)
                if img.lower().endswith(('.jpg', '.jpeg', '.png'))
            ]
            self.person_to_images[person] = images

        self.persons = list(self.person_to_images.keys())

        # Prepare pairs (balanced positive and negative)
        self.pairs = []
        self.labels = []
        half = num_pairs // 2

        # Positive pairs
        for _ in range(half):
            person = self.persons[_ % len(self.persons)]
            imgs = self.person_to_images[person]
            if len(imgs) < 2:
                continue
            img1, img2 = imgs[0], imgs[1]
            self.pairs.append((img1, img2))
            self.labels.append(1)

        # Negative pairs
        for _ in range(half):
            person1, person2 = self.persons[_ % len(self.persons)], self.persons[( _ + 1) % len(self.persons)]
            img1 = self.person_to_images[person1][0]
            img2 = self.person_to_images[person2][0]
            self.pairs.append((img1, img2))
            self.labels.append(0)

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        img1_path, img2_path = self.pairs[idx]
        label = self.labels[idx]

        img1 = Image.open(img1_path).convert('RGB')
        img2 = Image.open(img2_path).convert('RGB')

        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        return img1, img2, label

# --- Triplet margin accuracy ---
def triplet_margin_accuracy(anchor, positive, negative, margin=1.0):
    with torch.no_grad():
        d_pos = (anchor - positive).pow(2).sum(1)  # squared distance
        d_neg = (anchor - negative).pow(2).sum(1)
        correct = (d_pos + margin < d_neg).sum().item()
        return correct / anchor.size(0)

# --- Validation function ---
def validate(model, val_loader, device, threshold=1.0):
    model.eval()
    distances = []
    labels = []

    with torch.no_grad():
        for img1, img2, label in val_loader:
            img1, img2 = img1.to(device), img2.to(device)
            emb1 = model(img1)
            emb2 = model(img2)

            dist = (emb1 - emb2).pow(2).sum(1).sqrt()  # Euclidean distance
            distances.extend(dist.cpu().numpy())
            labels.extend(label.numpy())

    distances = torch.tensor(distances)
    labels = torch.tensor(labels)

    # Accuracy at threshold
    preds = (distances < threshold).long()
    acc = accuracy_score(labels, preds)
    try:
        auc = roc_auc_score(labels, -distances)  # invert distances for ROC
    except:
        auc = 0.0

    return acc, auc

# --- Config and Transforms ---
DATA_DIR = "/Users/mac/Downloads/face_recog_emb/data/lfw"
BATCH_SIZE = 32
EPOCHS = 20
LR = 1e-3
MARGIN = 1.0
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

transform = transforms.Compose([
    transforms.Resize((160, 160)),
    transforms.ToTensor(),
    transforms.Normalize([0.5]*3, [0.5]*3)
])

# Load valid names for filtering dataset
valid_names = [name for name in os.listdir(DATA_DIR) if os.path.isdir(os.path.join(DATA_DIR, name))]

# --- Datasets and loaders ---
train_dataset = TripletLFWDataset(root_dir=DATA_DIR, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)

val_dataset = ValidationPairsDataset(root_dir=DATA_DIR, valid_names=valid_names, transform=transform)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

# --- Model, Loss, Optimizer ---
model = FaceEmbeddingNet().to(DEVICE)
criterion = TripletLoss(margin=MARGIN)
optimizer = torch.optim.Adam(model.parameters(), lr=LR)

# --- Training loop ---
for epoch in range(1, EPOCHS + 1):
    model.train()
    running_loss = 0.0
    running_acc = 0.0

    pbar = tqdm(train_loader, desc=f"Epoch [{epoch}/{EPOCHS}]")
    for anchor, positive, negative in pbar:
        anchor, positive, negative = anchor.to(DEVICE), positive.to(DEVICE), negative.to(DEVICE)

        # Forward pass
        anchor_out = model(anchor)
        positive_out = model(positive)
        negative_out = model(negative)

        # Loss
        loss = criterion(anchor_out, positive_out, negative_out)

        # Backward and optimize
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Triplet margin accuracy
        acc = triplet_margin_accuracy(anchor_out, positive_out, negative_out, margin=MARGIN)

        running_loss += loss.item()
        running_acc += acc
        pbar.set_postfix(loss=loss.item(), triplet_acc=acc)

    epoch_loss = running_loss / len(train_loader)
    epoch_acc = running_acc / len(train_loader)

    # Validation
    val_acc, val_auc = validate(model, val_loader, DEVICE, threshold=1.0)

    print(f"Epoch {epoch}: Train Loss={epoch_loss:.4f}, Train Triplet Acc={epoch_acc:.4f}, "
          f"Val Acc={val_acc:.4f}, Val ROC AUC={val_auc:.4f}")

    # Save model checkpoint
    torch.save(model.state_dict(), f"model_epoch_{epoch}.pth")



