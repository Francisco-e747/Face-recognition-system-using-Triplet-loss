
# model.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class FaceEmbeddingNet(nn.Module):
    def __init__(self, embedding_size=128):
        super(FaceEmbeddingNet, self).__init__()
        self.convnet = nn.Sequential(
            nn.Conv2d(3, 32, 5),       # [3, 160, 160] → [32, 156, 156]
            nn.ReLU(),
            nn.MaxPool2d(2),           # → [32, 78, 78]

            nn.Conv2d(32, 64, 5),      # → [64, 74, 74]
            nn.ReLU(),
            nn.MaxPool2d(2),           # → [64, 37, 37]

            nn.Conv2d(64, 128, 3),     # → [128, 35, 35]
            nn.ReLU(),
            nn.MaxPool2d(2),           # → [128, 17, 17]
        )

        self.fc = nn.Sequential(
            nn.Linear(128 * 17 * 17, 512),
            nn.ReLU(),
            nn.Linear(512, embedding_size)
        )

    def forward(self, x):
        x = self.convnet(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        x = F.normalize(x, p=2, dim=1)  # Normalize embeddings
        return x



