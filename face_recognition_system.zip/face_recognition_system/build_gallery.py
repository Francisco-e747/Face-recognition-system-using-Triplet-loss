"The core process here is to identidy a user that was during training and those who were not will be set as unkown as"
"they will have a low confidence so low threshold"

# build_gallery.py
import os
import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from model import FaceEmbeddingNet 
# Config
DATA_DIR = "./data/lfw"
EMBEDDING_DIR = "./embeddings"
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Transform
transform = transforms.Compose([
    transforms.Resize((160, 160)),
    transforms.ToTensor(),
    transforms.Normalize([0.5]*3, [0.5]*3)
])

# Load trained model
model = FaceEmbeddingNet()
model.load_state_dict(torch.load("model_epoch_20.pth", map_location=DEVICE))
model.eval().to(DEVICE)

os.makedirs(EMBEDDING_DIR, exist_ok=True)

with torch.no_grad():
    for person in os.listdir(DATA_DIR):
        person_dir = os.path.join(DATA_DIR, person)
        if not os.path.isdir(person_dir):
            continue

        embeddings = []
        for img_name in os.listdir(person_dir):
            if not img_name.lower().endswith(('.jpg', '.jpeg', '.png')):
                continue

            img_path = os.path.join(person_dir, img_name)
            image = Image.open(img_path).convert("RGB")
            image = transform(image).unsqueeze(0).to(DEVICE)
            emb = model(image).cpu().numpy()
            embeddings.append(emb)

        if embeddings:
            # Average embedding per person
            mean_embedding = np.mean(np.vstack(embeddings), axis=0)
            np.save(os.path.join(EMBEDDING_DIR, f"{person}.npy"), mean_embedding)


